package com.jmails.api.service;

import com.jmails.api.entity.Jmail;
import com.jmails.api.repository.jmails.JmailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JmailsService {

    @Autowired
    private JmailsRepository jmailsRepository;

    @Autowired
    @Qualifier("jmailsMongoTemplate")
    private MongoTemplate jmailsMongoTemplate;

    /**
     * Listar todos los jmails con paginación.
     */
    public Page<Jmail> listarTodos(int page, int size) {
        return jmailsRepository.findAll(PageRequest.of(page, size));
    }

    /**
     * Buscar dentro de json_data convirtiéndolo a string.
     * Usa $where para ejecutar JavaScript en MongoDB.
     *
     * Ejemplo: buscar("hello") encontrará cualquier jmail cuyo
     * json_data contenga "hello" en cualquier campo o valor.
     */
    public List<Jmail> buscar(String texto) {
        // Escapar caracteres especiales de regex
        String textoEscapado = texto.replaceAll("([.*+?^${}()|\\[\\]\\\\])", "\\\\$1");

        String queryStr = String.format(
                "{ $where: \"JSON.stringify(this.json_data).match(/%s/i) != null\" }",
                textoEscapado
        );

        BasicQuery query = new BasicQuery(queryStr);
        return jmailsMongoTemplate.find(query, Jmail.class);
    }

    /**
     * Contar total de documentos.
     */
    public long contarTotal() {
        return jmailsRepository.count();
    }
}